
import React, { useState, useEffect, useRef } from 'react';

export default function App() {
  const [view, setView] = useState('home');
  const [profileName, setProfileName] = useState(() => localStorage.getItem('name') || 'Foydalanuvchi');

  // Listening sample
  const listeningQuestions = [
    { id: 1, time: '0:00-0:30', text: 'What does the speaker say is the best time to visit the botanical garden?', choices: ['Morning','Afternoon','Evening','Night'], answer: 0 },
    { id: 2, time: '0:31-1:00', text: "How much is the entrance fee for students?", choices: ['Free','2 USD','5 USD','10 USD'], answer: 2 },
  ];
  const [listeningAnswers, setListeningAnswers] = useState(() => JSON.parse(localStorage.getItem('listeningAnswers')||'[]'));
  const [listeningTimeLeft, setListeningTimeLeft] = useState(5*60);
  const listeningTimerRef = useRef(null);

  // Reading sample
  const readingPassages = [
    { id:1, title:'Short Passage — Urban Gardens', text:'Urban community gardens have grown in popularity. They provide green spaces, food and social benefits. Many projects are volunteer-run and supported by local councils.', questions:[
      { id:1, text: 'Who often supports urban garden projects?', choices:['Corporations','Local councils','Unknown','Private investors'], answer:1 },
      { id:2, text: 'Urban gardens are mainly run by?', choices:['Volunteers','Paid staff','Government officials','Tourists'], answer:0 },
    ] }
  ];
  const [readingAnswers, setReadingAnswers] = useState(() => JSON.parse(localStorage.getItem('readingAnswers')||'{}'));
  const [readingTimeLeft, setReadingTimeLeft] = useState(10*60);

  // Writing
  const writingPrompts = {
    task1: "The chart below shows the percentage of people using public transport in a city between 2000 and 2020. Summarize the information by selecting and reporting the main features, and make comparisons where relevant.",
    task2: "Some people think that schools should focus on practical skills rather than academic knowledge. To what extent do you agree or disagree? Give reasons for your answer and include any relevant examples from your own knowledge or experience."
  };
  const [writingAnswers, setWritingAnswers] = useState(() => JSON.parse(localStorage.getItem('writingAnswers')||'{"task1":"","task2":""}'));

  // Speaking (record)
  const [recordings, setRecordings] = useState(() => JSON.parse(localStorage.getItem('recordings')||'{}'));
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);

  useEffect(()=>{ localStorage.setItem('listeningAnswers', JSON.stringify(listeningAnswers)); }, [listeningAnswers]);
  useEffect(()=>{ localStorage.setItem('readingAnswers', JSON.stringify(readingAnswers)); }, [readingAnswers]);
  useEffect(()=>{ localStorage.setItem('writingAnswers', JSON.stringify(writingAnswers)); }, [writingAnswers]);
  useEffect(()=>{ localStorage.setItem('recordings', JSON.stringify(recordings)); }, [recordings]);
  useEffect(()=>{ localStorage.setItem('name', profileName); }, [profileName]);

  useEffect(()=>{ if(view!=='listening'){ clearInterval(listeningTimerRef.current); return; } listeningTimerRef.current = setInterval(()=>{ setListeningTimeLeft(t=> t<=1?0:t-1); }, 1000); return ()=>clearInterval(listeningTimerRef.current); }, [view]);

  useEffect(()=>{ let ref; if(view==='reading'){ ref = setInterval(()=> setReadingTimeLeft(t=> t<=1?0:t-1), 1000); } return ()=> clearInterval(ref); }, [view]);

  const startRecording = async (part) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio:true });
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;
      audioChunksRef.current = [];
      mr.ondataavailable = (e) => audioChunksRef.current.push(e.data);
      mr.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setRecordings(r=> ({ ...r, [part]: { url, size: blob.size }}));
      };
      mr.start();
    } catch(err){
      alert('Microphone access kerak — iltimos ruxsat bering.');
    }
  };
  const stopRecording = (part) => { if(mediaRecorderRef.current && mediaRecorderRef.current.state!=='inactive') mediaRecorderRef.current.stop(); };
  const downloadRecording = (part) => {
    const r = recordings[part]; if(!r) return alert('Recording topilmadi.');
    const a = document.createElement('a'); a.href = r.url; a.download = `${profileName}_speaking_part${part}.webm`; a.click();
  };

  const gradeListening = () => { let score=0; for(let i=0;i<listeningQuestions.length;i++){ if(listeningAnswers[i]==null) continue; if(listeningAnswers[i]===listeningQuestions[i].answer) score++; } return { correct: score, total: listeningQuestions.length, percent: Math.round((score/listeningQuestions.length)*100) }; };
  const gradeReading = () => { let correct=0, total=0; for(const p of readingPassages){ for(const q of p.questions){ total++; if(readingAnswers[`${p.id}_${q.id}`]==null) continue; if(readingAnswers[`${p.id}_${q.id}`]===q.answer) correct++; } } return { correct, total, percent: Math.round((correct/total)*100) }; };

  const formatTime = (t) => { const mm = Math.floor(t/60).toString().padStart(2,'0'); const ss = (t%60).toString().padStart(2,'0'); return `${mm}:${ss}`; };

  return (
    <div style={{ fontFamily: 'Inter, system-ui, Arial', padding: 20, background: '#f7fafc', minHeight: '100vh' }}>
      <div style={{ maxWidth: 1000, margin: '0 auto', background: '#fff', borderRadius: 12, boxShadow: '0 6px 18px rgba(0,0,0,0.08)' }}>
        <div style={{ padding: 20, borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 style={{ margin:0 }}>IELTS Exam Practice</h1>
            <div style={{ color:'#666', marginTop:6 }}>Real-like mock tests for Listening, Reading, Writing, Speaking</div>
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <input value={profileName} onChange={(e)=>setProfileName(e.target.value)} style={{ padding:8, borderRadius:6, border:'1px solid #ddd' }} placeholder="Ismingiz" />
            <button onClick={()=>setView('home')} style={{ padding:'8px 12px', background:'#4f46e5', color:'#fff', borderRadius:6, border:'none' }}>Home</button>
          </div>
        </div>

        <div style={{ padding:20 }}>
          <nav style={{ display:'flex', gap:8, marginBottom:16 }}>
            <button onClick={()=>{ setView('listening'); setListeningTimeLeft(5*60); }} style={{ padding:8, borderRadius:6, border:'1px solid #eee', background: view==='listening'? '#eef2ff':'#fff' }}>Listening</button>
            <button onClick={()=>{ setView('reading'); setReadingTimeLeft(10*60); }} style={{ padding:8, borderRadius:6, border:'1px solid #eee', background: view==='reading'? '#eef2ff':'#fff' }}>Reading</button>
            <button onClick={()=>setView('writing')} style={{ padding:8, borderRadius:6, border:'1px solid #eee', background: view==='writing'? '#eef2ff':'#fff' }}>Writing</button>
            <button onClick={()=>setView('speaking')} style={{ padding:8, borderRadius:6, border:'1px solid #eee', background: view==='speaking'? '#eef2ff':'#fff' }}>Speaking</button>
            <button onClick={()=>setView('review')} style={{ padding:8, borderRadius:6, border:'1px solid #eee', background: view==='review'? '#eef2ff':'#fff' }}>Review</button>
          </nav>

          {view==='home' && (
            <div>
              <h2>Qisqacha ko'rsatma</h2>
              <ul>
                <li>Listening va Reading bo'limlari uchun vaqtni to'liq ishlating — real imtihon topshirgandek.</li>
                <li>Writing bo'limida yozing, so'zlar sonini pastda ko'rasiz.</li>
                <li>Speaking bo'limida mikrofondan foydalanib javob yozib oling — keyin yuklab olishingiz mumkin.</li>
              </ul>
            </div>
          )}

          {view==='listening' && (
            <div>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                <h3>Listening — Sample</h3>
                <div>Time left: <strong>{formatTime(listeningTimeLeft)}</strong></div>
              </div>
              <div style={{ border:'1px solid #eee', padding:12, borderRadius:8, marginBottom:12 }}>
                <div>Audio player (sample):</div>
                <audio controls style={{ width:'100%', marginTop:8 }}>
                  <source src="https://www.kozco.com/tech/piano2-CoolEdit.mp3" type="audio/mpeg" />
                </audio>
                <div style={{ fontSize:12, color:'#666', marginTop:6 }}>* Bu shunchaki namuna audio. To'liq test uchun haqiqiy IELTS audio fayllarini joylang.</div>
              </div>

              {listeningQuestions.map((q,i)=>(
                <div key={q.id} style={{ border:'1px solid #eee', padding:12, borderRadius:8, marginBottom:10 }}>
                  <div style={{ color:'#666' }}>{q.time}</div>
                  <div style={{ fontWeight:600, marginTop:6 }}>{q.text}</div>
                  <div style={{ marginTop:8, display:'flex', gap:8, flexWrap:'wrap' }}>
                    {q.choices.map((c,idx)=>(
                      <label key={idx} style={{ padding:'6px 10px', borderRadius:6, border: listeningAnswers[i]===idx? '2px solid #4f46e5':'1px solid #ddd', cursor:'pointer' }}>
                        <input type="radio" name={`listen_${i}`} checked={listeningAnswers[i]===idx} onChange={()=> setListeningAnswers(s=>{ const copy=[...s]; copy[i]=idx; return copy; })} style={{ marginRight:6 }} />
                        {c}
                      </label>
                    ))}
                  </div>
                </div>
              ))}

              <div style={{ display:'flex', gap:8 }}>
                <button onClick={()=>{ const r=gradeListening(); alert(`Natija: ${r.correct}/${r.total} — ${r.percent}%`); }} style={{ padding:8, background:'#10b981', color:'#fff', borderRadius:6 }}>Tekshir</button>
                <button onClick={()=>{ setListeningAnswers([]); localStorage.removeItem('listeningAnswers'); }} style={{ padding:8, borderRadius:6 }}>Reset</button>
              </div>
            </div>
          )}

          {view==='reading' && (
            <div>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                <h3>Reading — Sample Passage</h3>
                <div>Time left: <strong>{formatTime(readingTimeLeft)}</strong></div>
              </div>

              {readingPassages.map(p=>(
                <div key={p.id} style={{ marginBottom:12 }}>
                  <h4>{p.title}</h4>
                  <p style={{ color:'#444' }}>{p.text}</p>
                  <div>
                    {p.questions.map(q=>(
                      <div key={q.id} style={{ border:'1px solid #eee', padding:10, borderRadius:8, marginBottom:8 }}>
                        <div style={{ fontWeight:600 }}>{q.text}</div>
                        <div style={{ marginTop:8, display:'flex', gap:8, flexWrap:'wrap' }}>
                          {q.choices.map((c,idx)=>(
                            <label key={idx} style={{ padding:'6px 10px', borderRadius:6, border: readingAnswers[`${p.id}_${q.id}`]===idx? '2px solid #4f46e5':'1px solid #ddd', cursor:'pointer' }}>
                              <input type="radio" name={`read_${p.id}_${q.id}`} checked={readingAnswers[`${p.id}_${q.id}`]===idx} onChange={()=> setReadingAnswers(s=> ({ ...s, [`${p.id}_${q.id}`]: idx }))} style={{ marginRight:6 }} />
                              {c}
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              <div style={{ display:'flex', gap:8 }}>
                <button onClick={()=>{ const r=gradeReading(); alert(`Reading: ${r.correct}/${r.total} — ${r.percent}%`); }} style={{ padding:8, background:'#10b981', color:'#fff', borderRadius:6 }}>Tekshir</button>
                <button onClick={()=>{ setReadingAnswers({}); localStorage.removeItem('readingAnswers'); }} style={{ padding:8, borderRadius:6 }}>Reset</button>
              </div>
            </div>
          )}

          {view==='writing' && (
            <div>
              <h3>Writing — Task 1 & Task 2</h3>
              <div style={{ display:'grid', gridTemplateColumns: '1fr', gap:12, marginTop:8 }}>
                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Task 1</h4>
                  <p style={{ color:'#666' }}>{writingPrompts.task1}</p>
                  <textarea value={writingAnswers.task1} onChange={(e)=> setWritingAnswers(s=> ({ ...s, task1: e.target.value }))} placeholder="Task 1 javobini shu yerga yozing..." style={{ width:'100%', minHeight:140, padding:10, borderRadius:6, border:'1px solid #ddd' }} />
                  <div style={{ fontSize:13, color:'#666', marginTop:6 }}>So'zlar: {writingAnswers.task1.trim() ? writingAnswers.task1.trim().split(/\s+/).length : 0} (recommended: 150+)</div>
                </div>

                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Task 2</h4>
                  <p style={{ color:'#666' }}>{writingPrompts.task2}</p>
                  <textarea value={writingAnswers.task2} onChange={(e)=> setWritingAnswers(s=> ({ ...s, task2: e.target.value }))} placeholder="Task 2 javobini shu yerga yozing..." style={{ width:'100%', minHeight:140, padding:10, borderRadius:6, border:'1px solid #ddd' }} />
                  <div style={{ fontSize:13, color:'#666', marginTop:6 }}>So'zlar: {writingAnswers.task2.trim() ? writingAnswers.task2.trim().split(/\s+/).length : 0} (recommended: 250+)</div>
                </div>
              </div>
              <div style={{ marginTop:10, padding:12, background:'#f8fafc', borderRadius:8 }}>
                <strong>Writing self-assessment rubric</strong>
                <ol style={{ marginTop:8 }}>
                  <li>Task Response — Did you answer the question fully?</li>
                  <li>Coherence & Cohesion — Is your writing organised with clear paragraphs?</li>
                  <li>Lexical Resource — Do you use a variety of vocabulary accurately?</li>
                  <li>Grammatical Range & Accuracy — Are your sentences grammatically correct and varied?</li>
                </ol>
                <div style={{ marginTop:8 }}>
                  <button onClick={()=> alert('Saqlangan. Javoblar localStorage-ga saqlandi.')} style={{ padding:8, background:'#4f46e5', color:'#fff', borderRadius:6 }}>Saqlash</button>
                  <button onClick={()=>{ setWritingAnswers({ task1:'', task2:'' }); localStorage.removeItem('writingAnswers'); }} style={{ padding:8, marginLeft:8, borderRadius:6 }}>Tozalash</button>
                </div>
              </div>
            </div>
          )}

          {view==='speaking' && (
            <div>
              <h3>Speaking — Mock (3 parts)</h3>
              <div style={{ display:'grid', gap:12, marginTop:8 }}>
                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Part 1 — Introduction & Interview</h4>
                  <p style={{ color:'#666' }}>Sample question: 'Where do you live? What do you like about your city?'</p>
                  <div style={{ display:'flex', gap:8, marginTop:8 }}>
                    <button onClick={()=> startRecording('part1')} style={{ padding:8, background:'#10b981', color:'#fff', borderRadius:6 }}>Start Recording</button>
                    <button onClick={()=> stopRecording('part1')} style={{ padding:8, borderRadius:6 }}>Stop</button>
                    <button onClick={()=> downloadRecording('part1')} style={{ padding:8, background:'#4f46e5', color:'#fff', borderRadius:6 }}>Download</button>
                  </div>
                  <div style={{ marginTop:8, fontSize:13 }}>{recordings.part1 ? `Yes (${Math.round(recordings.part1.size/1024)} KB)` : 'No'}</div>
                </div>

                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Part 2 — Long turn</h4>
                  <p style={{ color:'#666' }}>Cue card sample: Describe a memorable journey...</p>
                  <div style={{ display:'flex', gap:8, marginTop:8 }}>
                    <button onClick={()=> startRecording('part2')} style={{ padding:8, background:'#10b981', color:'#fff', borderRadius:6 }}>Start Recording</button>
                    <button onClick={()=> stopRecording('part2')} style={{ padding:8, borderRadius:6 }}>Stop</button>
                    <button onClick={()=> downloadRecording('part2')} style={{ padding:8, background:'#4f46e5', color:'#fff', borderRadius:6 }}>Download</button>
                  </div>
                  <div style={{ marginTop:8, fontSize:13 }}>{recordings.part2 ? `Yes (${Math.round(recordings.part2.size/1024)} KB)` : 'No'}</div>
                </div>

                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Part 3 — Discussion</h4>
                  <p style={{ color:'#666' }}>Sample question: 'How has travel changed in your country in the last 20 years?'</p>
                  <div style={{ display:'flex', gap:8, marginTop:8 }}>
                    <button onClick={()=> startRecording('part3')} style={{ padding:8, background:'#10b981', color:'#fff', borderRadius:6 }}>Start Recording</button>
                    <button onClick={()=> stopRecording('part3')} style={{ padding:8, borderRadius:6 }}>Stop</button>
                    <button onClick={()=> downloadRecording('part3')} style={{ padding:8, background:'#4f46e5', color:'#fff', borderRadius:6 }}>Download</button>
                  </div>
                  <div style={{ marginTop:8, fontSize:13 }}>{recordings.part3 ? `Yes (${Math.round(recordings.part3.size/1024)} KB)` : 'No'}</div>
                </div>

                <div style={{ padding:12, background:'#f8fafc', borderRadius:8 }}>
                  <strong>Speaking self-assessment</strong>
                  <ol style={{ marginTop:8 }}>
                    <li>Fluency & Coherence</li>
                    <li>Lexical Resource</li>
                    <li>Grammatical Range & Accuracy</li>
                    <li>Pronunciation</li>
                  </ol>
                </div>
              </div>
            </div>
          )}

          {view==='review' && (
            <div>
              <h3>Review & Scores</h3>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginTop:8 }}>
                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Listening</h4>
                  <pre style={{ whiteSpace:'pre-wrap' }}>{JSON.stringify(gradeListening(), null, 2)}</pre>
                </div>
                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Reading</h4>
                  <pre style={{ whiteSpace:'pre-wrap' }}>{JSON.stringify(gradeReading(), null, 2)}</pre>
                </div>
                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Writing</h4>
                  <div>Self-assess writing using the rubric in the Writing section.</div>
                </div>
                <div style={{ border:'1px solid #eee', padding:12, borderRadius:8 }}>
                  <h4>Speaking</h4>
                  <div>Download your recordings and send them to a teacher for feedback.</div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div style={{ padding:12, borderTop:'1px solid #eee', fontSize:13, color:'#666' }}>
          Bu demo app. Men yordam bera olaman: ko'proq savollar qo'shish, haqiqiy audio fayllar joylash yoki saytingizni Vercel-ga deploy qilishda yordam.
        </div>
      </div>
    </div>
  );
}
