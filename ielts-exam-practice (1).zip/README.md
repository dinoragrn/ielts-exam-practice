# IELTS Exam Practice

This is a lightweight React + Vite demo app for IELTS mock testing (Listening, Reading, Writing, Speaking).
It is intended for quick deployment to Vercel.

## How to run locally

1. Install Node.js (>= 18 recommended)
2. Run:
```
npm install
npm run dev
```
3. Open http://localhost:5173

## Deploy to Vercel

- Create a GitHub repository (you've already created `ielts-exam-practice`)
- Upload the files to the repository (commit)
- On Vercel, import the repository and click Deploy

